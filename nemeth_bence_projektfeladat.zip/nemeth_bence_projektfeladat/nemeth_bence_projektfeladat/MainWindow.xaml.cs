﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using nemeth_bence_projektfeladat.Model;
using nemeth_bence_projektfeladat.View;
using Org.BouncyCastle.Asn1.X509;

namespace nemeth_bence_projektfeladat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private PizzaWindow pizzaWindow;
        private RendeloWindow rendeloWindow;
        private RendelesWindow rendelesWindow;


        public MainWindow()
        {
            InitializeComponent();
            CheckDatabaseConnection();
        }

        private void CheckDatabaseConnection()
        {
            try
            {

                PizzaContext dbcontext = new PizzaContext();

                if (!dbcontext.Database.CanConnect())
                {
                    MessageBox.Show("Database Connection Failed");
                    System.Environment.Exit(1);

                }
                dbcontext.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Connection Failed!");

            }
        }


        private void PizzaWindow_Click(object sender, RoutedEventArgs e)
        {
            if (this.pizzaWindow == null)
            {
                PizzaWindow pizzaWindow = new PizzaWindow();
                pizzaWindow.ShowDialog();
            }
            else
            {
                this.pizzaWindow.ShowDialog();
            }
        }

        private void RendeloWindow_Click(object sender, RoutedEventArgs e)
        {
            if (this.rendeloWindow == null)
            {
                RendeloWindow rendeloWindow = new RendeloWindow();
                rendeloWindow.ShowDialog();
            }
            else
            {
                this.rendeloWindow.ShowDialog();
            }
        }

        private void RendelesWindow_Click(object sender, RoutedEventArgs e)
        {
            if (this.rendelesWindow == null)
            {
                RendelesWindow rendelesWindow = new RendelesWindow();
                rendelesWindow.ShowDialog();
            }
            else
            {
                this.rendelesWindow.ShowDialog();
            }
        }

        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
            

        }

        private void btn_rendeles_Click(object sender, RoutedEventArgs e)
        {
            /* rendelesi ido szamolas
            DateTime ido = DateTime.Now;
            ido = ido.AddMinutes(10);
            MessageBox.Show(Convert.ToString(ido));
            */
            if (this.rendeloWindow == null)
            {
                RendeloWindow rendeloWindow = new RendeloWindow();
                rendeloWindow.ShowDialog();
            }
            else
            {
                this.rendeloWindow.ShowDialog();
            }

        }

        private void btn_pizzak_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Jelenlegi kínálatunk bővítés alatt áll!");
            PizzaWindow_Click(sender, e);

        }

        private void btn_pizzak_Copy_Click(object sender, RoutedEventArgs e)
        {
            RendeloWindow_Click(sender, e);


        }

        private void btn_rendeles_Click_1(object sender, RoutedEventArgs e)
        {
            RendelesWindow_Click(sender, e);
        }
    }
}
