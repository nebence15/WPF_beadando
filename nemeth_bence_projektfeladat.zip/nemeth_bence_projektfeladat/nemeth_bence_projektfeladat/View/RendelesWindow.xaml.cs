﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using nemeth_bence_projektfeladat.Model;
using nemeth_bence_projektfeladat.Repository;

namespace nemeth_bence_projektfeladat.View
{
    /// <summary>
    /// Interaction logic for RendelesWindow.xaml
    /// </summary>
    public partial class RendelesWindow : Window
    {
        private RendelesRepository rendelesRepository = null;
        private List<Rendeles> selectRendeles;
        private PizzaRepository pizzaRepository = null;

        private Op operation = Op.No;
        enum Op
        {
            Add,
            Upd,
            No

        }


        public RendelesWindow()
        {
            InitializeComponent();
            rendelesRepository = new RendelesRepository(new PizzaContext());
            LoadRendelesGrid();
            comboBoxRendelo.IsEnabled = false;
            comboBoxPizza.IsEnabled = false;
        }

        private void LoadRendelesGrid()
        {
            Cursor = Cursors.Wait;
            selectRendeles = rendelesRepository.GetRendelesek();
            dataGrid.DataContext = selectRendeles;
            Cursor = Cursors.Arrow;

        }

        private void LoadComboBoxRendelo()
        {
            Cursor = Cursors.Wait;
            List<Rendelo> lstrendelo = new List<Rendelo>();
            RendeloRepository rendeloRep = new RendeloRepository(new PizzaContext());
            lstrendelo = rendeloRep.GetRendelo();
            comboBoxRendelo.ItemsSource = lstrendelo;
            comboBoxRendelo.SelectedValue = lstrendelo;
            comboBoxRendelo.DisplayMemberPath = "Nev";
            comboBoxRendelo.SelectedValuePath = "Id";
            lstrendelo = null;
            rendeloRep.Dispose();
            Cursor = Cursors.Arrow;


        }

        private void LoadcomboBoxPizza()
        {
            Cursor = Cursors.Wait;
            List<Pizza> lstpizza = new List<Pizza>();
            PizzaRepository pizzaRep = new PizzaRepository(new PizzaContext());
            lstpizza = pizzaRep.GetPizzak();
            comboBoxPizza.ItemsSource = lstpizza;
            comboBoxPizza.SelectedValue = lstpizza;
            comboBoxPizza.DisplayMemberPath = "Tipus";
            comboBoxPizza.SelectedValuePath = "Id";
            lstpizza = null;
            pizzaRep.Dispose();
            Cursor = Cursors.Arrow;

            

        }


        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void btn_new_Click(object sender, RoutedEventArgs e)
        {
            comboBoxRendelo.IsEnabled = true;
            comboBoxPizza.IsEnabled = true;
            LoadComboBoxRendelo();
            LoadcomboBoxPizza();
            operation = Op.Add;



        }

        private void btn_save_Click(object sender, RoutedEventArgs e)
        {
            if (operation == Op.Add && comboBoxRendelo.SelectedValue != ""
                 && comboBoxPizza.SelectedValue != "")
            {
                rendelesRepository.InsertRendeles(new Rendeles
                {
                    
                    PizzaId = Convert.ToInt32(comboBoxPizza.SelectedValue),
                    RendeloId = Convert.ToInt32(comboBoxRendelo.SelectedValue),


                });

                rendelesRepository.Save();
                LoadRendelesGrid();

                comboBoxRendelo.IsEnabled = false;
                comboBoxPizza.IsEnabled = false;
                comboBoxRendelo.SelectedValue = null;
                comboBoxPizza.SelectedValue = null;


                operation = Op.No;


            }
            else
            {
                MessageBox.Show("Operation is not INSERT");
            }


        }

        private void dataGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (selectRendeles.Count != 0 && dataGrid.SelectedIndex < selectRendeles.Count)

            {
                LoadComboBoxRendelo();
                comboBoxRendelo.IsEnabled = true;
                comboBoxRendelo.SelectedValue = selectRendeles[dataGrid.SelectedIndex].RendeloId;

                LoadcomboBoxPizza();
                comboBoxPizza.IsEnabled = true;
                comboBoxPizza.SelectedValue = selectRendeles[dataGrid.SelectedIndex].PizzaId;               

                operation = Op.Upd;


            }
        }

        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            if (operation == Op.Upd)
            {
                rendelesRepository.DeleteRendeles(selectRendeles[dataGrid.SelectedIndex].Id);
                rendelesRepository.Save();
                LoadRendelesGrid();
                LoadComboBoxRendelo();
                LoadcomboBoxPizza();
                comboBoxRendelo.SelectedValue = null;
                comboBoxPizza.SelectedValue = null;

                comboBoxRendelo.IsEnabled = false;
                comboBoxPizza.IsEnabled = false;

                operation = Op.No;

            }
        }

        private void btn_update_Click(object sender, RoutedEventArgs e)
        {
            if (operation == Op.Upd)
            {
                Rendeles rendeles_update = rendelesRepository.GetRendelesById(selectRendeles[dataGrid.SelectedIndex].Id);
                rendelesRepository.GetRendelesById(selectRendeles[dataGrid.SelectedIndex].Id);
                rendeles_update.RendeloId = Convert.ToInt32(comboBoxRendelo.SelectedValue);
                rendeles_update.PizzaId = Convert.ToInt32(comboBoxPizza.SelectedValue);                
                rendelesRepository.UpdateRendeles(rendeles_update);
                rendelesRepository.Save();
                LoadRendelesGrid();
                LoadComboBoxRendelo();
                LoadcomboBoxPizza();
                comboBoxRendelo.SelectedValue = null;
                comboBoxPizza.SelectedValue = null;


                comboBoxRendelo.IsEnabled = false;
                comboBoxPizza.IsEnabled = false;
                

                operation = Op.No;

            }
            else
            {
                MessageBox.Show("Operation is not UPDATE");
            }
        }

        
    }

}
