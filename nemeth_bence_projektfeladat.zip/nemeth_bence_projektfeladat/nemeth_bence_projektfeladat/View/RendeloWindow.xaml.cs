﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using nemeth_bence_projektfeladat.Model;
using nemeth_bence_projektfeladat.Repository;

namespace nemeth_bence_projektfeladat.View
{
    /// <summary>
    /// Interaction logic for RendeloWindow.xaml
    /// </summary>
    public partial class RendeloWindow : Window
    {
        private RendeloRepository rendeloRepository = null;
        private List<Rendelo> selectRendelok;

        private Op operation = Op.No;
        enum Op
        {
            Add,
            Upd,
            No

        }


        public RendeloWindow()
        {
            InitializeComponent();
            rendeloRepository = new RendeloRepository(new PizzaContext());
            LoadRendeloGrid();
            textBoxNev.IsEnabled = false;
            textBoxLakcim.IsEnabled = false;
            textBoxKiszallitasi_ido.IsEnabled = false;
            


        }

        private void LoadRendeloGrid()
        {
            Cursor = Cursors.Wait;
            selectRendelok = rendeloRepository.GetRendelo();
            dataGrid.DataContext = selectRendelok;
            Cursor = Cursors.Arrow;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void buttonNew_Click(object sender, RoutedEventArgs e)
        {
            textBoxNev.IsEnabled = true;
            textBoxLakcim.IsEnabled = true;
            textBoxKiszallitasi_ido.IsEnabled = true;           
            textBoxNev.Text = "";
            textBoxLakcim.Text = "";
            textBoxKiszallitasi_ido.Text = "";

            operation = Op.Add;
            textBoxNev.Focus();

        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            if (operation == Op.Add && textBoxNev.Text != ""
                && textBoxNev.Text != ""
                && textBoxLakcim.Text != ""
                && textBoxKiszallitasi_ido.Text != "")
            {
                rendeloRepository.InsertRendelo(new Rendelo
                {
                    Nev = textBoxNev.Text,
                    Lakcim = textBoxLakcim.Text,
                    Plusz_kiszallitasi_ido = Convert.ToInt32(textBoxKiszallitasi_ido.Text),

                });

                rendeloRepository.Save();
                LoadRendeloGrid();

                textBoxNev.IsEnabled = false;
                textBoxLakcim.IsEnabled = false;
                textBoxKiszallitasi_ido.IsEnabled = false;
                
                textBoxNev.Text = "";
                textBoxLakcim.Text = "";
                textBoxKiszallitasi_ido.Text = "";
                operation = Op.No;


            }
            else
            {
                MessageBox.Show("Operation is not INSERT");
            }

        }

        private void buttonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (operation == Op.Upd)
            {
                rendeloRepository.GetRendeloById(selectRendelok[dataGrid.SelectedIndex].Id);
                rendeloRepository.DeleteRendelo(selectRendelok[dataGrid.SelectedIndex].Id);
                rendeloRepository.Save();
                LoadRendeloGrid();
                textBoxNev.Text = "";
                textBoxLakcim.Text = "";
                textBoxKiszallitasi_ido.Text = "";

                textBoxNev.IsEnabled = false;
                textBoxLakcim.IsEnabled = false;
                textBoxKiszallitasi_ido.IsEnabled = false;

                operation = Op.No;

            }




        }

        private void dataGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (selectRendelok.Count != 0 && dataGrid.SelectedIndex < selectRendelok.Count)
            {
                textBoxNev.Text = selectRendelok[dataGrid.SelectedIndex].Nev;
                textBoxLakcim.Text = selectRendelok[dataGrid.SelectedIndex].Lakcim;
                textBoxKiszallitasi_ido.Text = Convert.ToString(selectRendelok[dataGrid.SelectedIndex].Plusz_kiszallitasi_ido);
               
                textBoxNev.IsEnabled = true;
                textBoxLakcim.IsEnabled = true;
                textBoxKiszallitasi_ido.IsEnabled = true;

                operation = Op.Upd;
                textBoxNev.Focus();

            }


        }

        private void update_button_Click(object sender, RoutedEventArgs e)
        {
            if (operation == Op.Upd)
            {
                Rendelo rendelo_update = rendeloRepository.GetRendeloById(selectRendelok[dataGrid.SelectedIndex].Id);
                rendeloRepository.GetRendeloById(selectRendelok[dataGrid.SelectedIndex].Id);
                rendelo_update.Nev = textBoxNev.Text;
                rendelo_update.Lakcim = textBoxLakcim.Text;
                rendelo_update.Plusz_kiszallitasi_ido = Convert.ToInt32(textBoxKiszallitasi_ido.Text);
               
                rendeloRepository.UpdateRendelo(rendelo_update);
                rendeloRepository.Save();
                LoadRendeloGrid();
                textBoxNev.Text = "";
                textBoxLakcim.Text = "";
                textBoxKiszallitasi_ido.Text = "";
               

                textBoxNev.IsEnabled = false;
                textBoxLakcim.IsEnabled = false;
                textBoxKiszallitasi_ido.IsEnabled = false;
               

                operation = Op.No;

            }
            else
            {
                MessageBox.Show("Operation is not UPDATE");
            }



        }
    }
}