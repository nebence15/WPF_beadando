﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using nemeth_bence_projektfeladat.Repository;
using nemeth_bence_projektfeladat.Model;

namespace nemeth_bence_projektfeladat.View
{
    /// <summary>
    /// Interaction logic for PizzaWindow.xaml
    /// </summary>
    public partial class PizzaWindow : Window
    {
        private PizzaWindow pizzaWindow;
        private RendeloWindow rendeloWindow;
        private RendelesWindow rendelesWindow;
        private PizzaRepository pizzaRepository = null;
        private List<Pizza> selectPizzak;

        private Op operation = Op.No;
        enum Op
        {
            Add,
            Upd,
            No

        }



        public PizzaWindow()
        {
            InitializeComponent();
            pizzaRepository = new PizzaRepository(new PizzaContext());
            LoadRendeloGrid();
         
        }

        private void LoadRendeloGrid()
        {
            Cursor = Cursors.Wait;
            selectPizzak = pizzaRepository.GetPizzak();
            dataGrid.DataContext = selectPizzak;
            Cursor = Cursors.Arrow;
        }

        private void btn_rendelek_Click(object sender, RoutedEventArgs e)
        {
            if (this.rendelesWindow == null)
            {
                RendelesWindow rendelesWindow = new RendelesWindow();
                rendelesWindow.ShowDialog();
            }
            else
            {
                this.rendelesWindow.ShowDialog();
            }

        }

        private void btn_exit_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void dataGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            
        }
    }
}
