﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nemeth_bence_projektfeladat.Model
{
       
        [Table("rendelesek")]
        class Rendeles
        {
            [Key]

            [Column("id")]
            public int Id { get; set; }

            [Column("pizzaid")]
            public int PizzaId { get; set; }

            [Column("rendeloid")]
            public int RendeloId { get; set; }

            [Column("vegosszeg")]
            public int Vegosszeg { get; set; }

            [Column("varhato_kiszallitas")]
            public int Varhato_kiszallitas { get; set; }


    }
    
}
