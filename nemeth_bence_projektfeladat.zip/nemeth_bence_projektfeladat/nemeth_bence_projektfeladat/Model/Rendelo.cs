﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nemeth_bence_projektfeladat.Model
{   
    
       [Table("rendelok")]
        class Rendelo
        {
            [Key]

            [Column("id")]
            public int Id { get; set; }

            [Column("nev")]
            public string Nev { get; set; }

            [Column("lakcim")]
            public string Lakcim{ get; set; }

            [Column("plusz_kiszallitasi_ido")]
            public int Plusz_kiszallitasi_ido { get; set; }


        }
    
}
