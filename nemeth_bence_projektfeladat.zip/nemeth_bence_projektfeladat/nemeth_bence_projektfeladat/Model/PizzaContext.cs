﻿using System;
using Microsoft.EntityFrameworkCore;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nemeth_bence_projektfeladat.Model
{
    class PizzaContext : DbContext
    {
        private string connectionString = ConfigurationManager.AppSettings.Get("DBurl");


        public PizzaContext()
        {
            this.connectionString = connectionString;

        }

        public DbSet<Pizza> Pizzak { get; set; }
        public DbSet<Rendelo> Rendelok { get; set; }
        public DbSet<Rendeles> Rendelesek { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL(connectionString);
        }

    }
}
