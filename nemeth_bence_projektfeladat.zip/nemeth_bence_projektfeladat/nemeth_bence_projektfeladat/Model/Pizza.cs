﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nemeth_bence_projektfeladat.Model
{
    [Table("pizzak")]
    class Pizza
    {
        [Key]

        [Column("id")]
        public int Id { get; set; }

        [Column("tipus")]
        public string Tipus{ get; set; }

        [Column("ar")]
        public int Ar { get; set; }

        [Column("elkeszitesi_ido")]
        public int Elkeszitesi_ido { get; set; }
      

    }
}
