﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using nemeth_bence_projektfeladat.Model;

namespace nemeth_bence_projektfeladat.Repository
{
    class PizzaRepository
    {
        private PizzaContext pizzaContext;
        public PizzaRepository(PizzaContext context)
        {
            this.pizzaContext = context;
        }

        public List<Pizza> GetPizzak()
        {
            return pizzaContext.Pizzak.ToList();
        }

        public Pizza GetPizzaById(int id)
        {
            return pizzaContext.Pizzak.Find(id);
        }

        public void InsertPizza(Pizza pizza)
        {
            pizzaContext.Pizzak.Add(pizza);

        }

        public void DeletePizza(int pizzaId)
        {
            Pizza pizza = pizzaContext.Pizzak.Find(pizzaId);
            pizzaContext.Pizzak.Remove(pizza);
        }

        public void UpdatePizza(Pizza pizza)
        {
            pizzaContext.Pizzak.Find(pizza.Id).Tipus = pizza.Tipus;
            pizzaContext.Pizzak.Find(pizza.Id).Ar = pizza.Ar;
            pizzaContext.Pizzak.Find(pizza.Id).Elkeszitesi_ido = pizza.Elkeszitesi_ido;


        }

        public void Save()
        {
            pizzaContext.SaveChanges();

        }

        public void Dispose()
        {
            pizzaContext.Dispose();
            GC.SuppressFinalize(this);
        }

        public int getAr(Pizza pizza)
        {
            return pizzaContext.Pizzak.Find(pizza.Id).Ar;
        }

    }
}
