﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using nemeth_bence_projektfeladat.Model;

namespace nemeth_bence_projektfeladat.Repository
{
    class RendelesRepository
    {
        private PizzaContext pizzaContext;
        public RendelesRepository(PizzaContext context)
        {
            this.pizzaContext = context;
        }

        public List<Rendeles> GetRendelesek()
        {
            return pizzaContext.Rendelesek.ToList();
        }

        public Rendeles GetRendelesById(int id)
        {
            return pizzaContext.Rendelesek.Find(id);
        }

        public void InsertRendeles(Rendeles rendeles)
        {
            pizzaContext.Rendelesek.Add(rendeles);

        }

        public void DeleteRendeles(int rendelesID)
        {
            Rendeles rendeles = pizzaContext.Rendelesek.Find(rendelesID);
            pizzaContext.Rendelesek.Remove(rendeles);
        }

        public void UpdateRendeles(Rendeles rendeles)
        {
            pizzaContext.Rendelesek.Find(rendeles.Id).PizzaId = rendeles.PizzaId;
            pizzaContext.Rendelesek.Find(rendeles).RendeloId = rendeles.RendeloId;
            pizzaContext.Rendelesek.Find(rendeles).Vegosszeg = rendeles.Vegosszeg;
            pizzaContext.Rendelesek.Find(rendeles).Varhato_kiszallitas = rendeles.Varhato_kiszallitas;

        }

        public void Save()
        {
            pizzaContext.SaveChanges();

        }

        public void Dispose()
        {
            pizzaContext.Dispose();
            GC.SuppressFinalize(this);
        }


    }
}
