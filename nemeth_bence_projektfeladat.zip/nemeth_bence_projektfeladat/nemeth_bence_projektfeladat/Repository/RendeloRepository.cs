﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using nemeth_bence_projektfeladat.Model;

namespace nemeth_bence_projektfeladat.Repository
{
    class RendeloRepository
    {
        private PizzaContext pizzaContext;
        public RendeloRepository(PizzaContext context)
        {
            this.pizzaContext = context;
        }

        public List<Rendelo> GetRendelo()
        {
            return pizzaContext.Rendelok.ToList();
        }

        public Rendelo GetRendeloById(int id)
        {
            return pizzaContext.Rendelok.Find(id);
        }

        public void InsertRendelo(Rendelo rendelo)
        {
            pizzaContext.Rendelok.Add(rendelo);

        }

        public void DeleteRendelo(int rendeloID)
        {
            Rendelo rendelo = pizzaContext.Rendelok.Find(rendeloID);
            pizzaContext.Rendelok.Remove(rendelo);
        }

        public void UpdateRendelo(Rendelo rendelo)
        {
            pizzaContext.Rendelok.Find(rendelo.Id).Nev = rendelo.Nev;
            pizzaContext.Rendelok.Find(rendelo.Id).Lakcim = rendelo.Lakcim;
            pizzaContext.Rendelok.Find(rendelo.Id).Plusz_kiszallitasi_ido = rendelo.Plusz_kiszallitasi_ido;
            
        }

        public void Save()
        {
            pizzaContext.SaveChanges();

        }

        public void Dispose()
        {
            pizzaContext.Dispose();
            GC.SuppressFinalize(this);
        }

    }
}
